<div align="center">
  <img width="200" height="200"
    src="https://s3.amazonaws.com/pix.iemoji.com/images/emoji/apple/ios-11/256/crayon.png">
  <h1>@jimp/core</h1>
</div>

The main Jimp class. This class can be extended with types and bitmap manipulation functions. Out of the box it does not support any image type.

- [print](http://jimp-dev.github.io/jimp/api/jimp/classes/jimp#print)
- [loadFont](http://jimp-dev.github.io/jimp/api/jimp/functions/loadfont/)
