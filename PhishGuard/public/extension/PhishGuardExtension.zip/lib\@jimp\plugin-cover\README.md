<div align="center">
  <img width="200" height="200"
    src="https://s3.amazonaws.com/pix.iemoji.com/images/emoji/apple/ios-11/256/crayon.png">
  <h1>@jimp/plugin-cover</h1>
  <p>Cover an image within a height and width.</p>
</div>

- [cover](http://jimp-dev.github.io/jimp/api/jimp/classes/jimp#cover)
