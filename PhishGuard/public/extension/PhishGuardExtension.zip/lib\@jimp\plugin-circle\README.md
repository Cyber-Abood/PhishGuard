<div align="center">
  <img width="200" height="200"
    src="https://s3.amazonaws.com/pix.iemoji.com/images/emoji/apple/ios-11/256/crayon.png">
  <h1>@jimp/plugin-circle</h1>
  <p>Creates a circle out of an image.</p>
</div>

- [circle](http://jimp-dev.github.io/jimp/api/jimp/classes/jimp#circle)
