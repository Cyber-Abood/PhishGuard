<div align="center">
  <img width="200" height="200"
    src="https://s3.amazonaws.com/pix.iemoji.com/images/emoji/apple/ios-11/256/crayon.png">
  <h1>@jimp/plugin-resize</h1>
  <p>Resize an image.</p>
</div>

Resizes the image to a set width and height using a 2-pass bilinear algorithm.

- [resize](http://jimp-dev.github.io/jimp/api/jimp/classes/jimp#resize)
- [scale](http://jimp-dev.github.io/jimp/api/jimp/classes/jimp#scale)
- [scaleToFit](http://jimp-dev.github.io/jimp/api/jimp/classes/jimp#scaletofit)
