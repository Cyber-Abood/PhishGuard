<div align="center">
  <img width="200" height="200"
    src="https://s3.amazonaws.com/pix.iemoji.com/images/emoji/apple/ios-11/256/crayon.png">
  <h1>@jimp/plugin-rotate</h1>
  <p>Rotate an image.</p>
</div>

Rotates the image counter-clockwise by a number of degrees. By default the width and height of the image will be resized appropriately.

- [rotate](http://jimp-dev.github.io/jimp/api/jimp/classes/jimp#rotate)
