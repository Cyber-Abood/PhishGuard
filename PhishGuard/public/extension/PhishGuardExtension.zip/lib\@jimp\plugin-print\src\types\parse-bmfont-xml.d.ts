declare module "parse-bmfont-xml" {
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  export default function parseXML(data: string): any;
}
